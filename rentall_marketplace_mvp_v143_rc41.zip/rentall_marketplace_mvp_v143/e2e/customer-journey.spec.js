import {test,expect} from '@playwright/test';

test.describe('RentAll customer journey',()=>{
 test('home → discovery → listing detail is navigable',async({page})=>{
   await page.goto('/');
   await expect(page.locator('body')).toBeVisible();
   const search=page.locator('#searchInput');
   if(await search.count()){await search.fill('camera');await search.press('Enter').catch(()=>{});}
   const card=page.locator('[data-listing-id], .listing-card').first();
   await expect(card).toBeVisible();
   await card.click();
   await expect(page.locator('#listingDetailModal, #listingDetail, .listing-detail-modal').first()).toBeVisible();
 });
 test('booking surface exposes dates, quantity and authoritative total',async({page})=>{
   await page.goto('/');
   const card=page.locator('[data-listing-id], .listing-card').first();await card.click();
   const modal=page.locator('#listingDetailModal, #listingDetail, .listing-detail-modal').first();
   await expect(modal).toBeVisible();
   await expect(page.locator('text=/per day|day/i').first()).toBeVisible();
 });
 test('supplier sign-up keeps first step focused',async({page})=>{
   await page.goto('/');
   await page.locator('[data-auth-tab="register"]').first().click().catch(async()=>{await page.locator('text=/sign up|create account/i').first().click()});
   await expect(page.locator('#supplierRegisterForm')).toBeVisible();
   await expect(page.locator('#regEmail')).toBeVisible();
   await expect(page.locator('#regPlan')).toHaveCount(0);
 });
});
